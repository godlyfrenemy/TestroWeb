<html class="" lang="en">
    <head>
        <meta charset="utf-8">
            <meta content="noindex" name="robots">
                <link href="https://cpwebassets.codepen.io/assets/favicon/favicon-aec34940fbc1a6e787974dcd360f2c6b63348d4b1f4e06c77743096d55480f33.ico" rel="shortcut icon" type="image/x-icon">
                    <link color="#111" href="https://cpwebassets.codepen.io/assets/favicon/logo-pin-b4b4269c16397ad2f0f7a01bcdf513a1994f4c94b8af2f191c09eb0d601762b1.svg" rel="mask-icon">
                        <link href="https://codepen.io/ig_design/pen/KKVQpVP?editors=1000" rel="canonical">
                            <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css" rel="stylesheet">
                                <link href="https://unicons.iconscout.com/release/v2.1.9/css/unicons.css" rel="stylesheet">
                                    <script src="https://cpwebassets.codepen.io/assets/editor/iframe/iframeConsoleRunner-6bce046e7128ddf9391ccf7acbecbf7ce0cbd7b6defbeb2e217a867f51485d25.js">
                                    </script>
                                    <script src="https://cpwebassets.codepen.io/assets/editor/iframe/iframeRefreshCSS-44fe83e49b63affec96918c9af88c0d80b209a862cf87ac46bc933074b8c557d.js">
                                    </script>
                                    <script src="https://cpwebassets.codepen.io/assets/editor/iframe/iframeRuntimeErrors-4f205f2c14e769b448bcf477de2938c681660d5038bc464e3700256713ebe261.js">
                                    </script>
                                    <style type="text/css">
                                        :root img[style*="//counter.yadro.ru/"], :root img[src^="/stat/"][width="88"][height="31"], :root img[src*="://c.bigmir.net/"], :root a[href^="http://hitcounter.ru/top/stat.php"], :root a[href*="/rating/"] > img[width="88"][height="31"], :root a[href*="//top.mail.ru/jump?"], :root a#mobtop[title^="Рейтинг мобильных сайтов"], :root [title="uWeb Counter"], :root [title="uCoz Counter"], :root .min-width-normal > #popup_container ~ #fade, :root .min-width-normal > #popup_container, :root body > div[class^="_"][class*=" _"][class$="_stBig"], :root body > div[style="position: fixed; z-index: 999999; width: 400px; height: 308px; right: 5px; bottom: 5px;"], :root body > div[id^="dV"][style^="width"][style*="height"][style*="position"][style*="fixed"][style*="overflow"][style*="z-index"][style*="background"], :root .flex-promo-series > .left-col > :not(#players):not(.serial-series-info), :root a[href*="://news.mirtesen.ru/newdata/"], :root .app.blog-post-page .secondary-header-ad-block, :root .app.blog-post-page #blog-post-item-video-ad, :root #root > .app .sportrecs, :root #root > .app #very-right-column, :root body.has-brand .b-content__main > div[id]:not([class]):empty, :root body.has-brand .b-content__main .b-player a[href*="aHR0c"], :root div[style="width: 252px; height: 450px; position: fixed; right: 0px; top: 0px; overflow: hidden; z-index: 10000;"], :root thetruestory-widget-top, :root object[data^="blob"], :root img[width="728"][height="90"], :root img[width="160"][height="600"], :root img[width="120"][height="600"], :root iframe[src*="trafic-media.ru"], :root iframe[src*="hd.gg33.top/"], :root iframe[src*="ads.exosrv.com"], :root iframe[src*="://vidroll.ru/"], :root iframe[src*="://promo-bc.com/"], :root iframe[src*="://partner-widget.vsesdal.com/"], :root iframe[src*="://mark-media.com.ua"], :root iframe[src*="://ab.adpro.com.ua/"], :root iframe[src*="/mixadv_"], :root iframe[src*="/carta.ua/ajax/widget."], :root iframe[src*="/3647.tech"], :root iframe[id^="republer"], :root iframe[data-src*="fwdcdn.com/frame/partners/"], :root div[id^="yandex_rtb"], :root div[id^="trafmag_"], :root div[id^="tizerws_"], :root div[id^="rtn4p"], :root div[id^="republer_"], :root div[id^="news_nest_net_ru"], :root div[id^="news_2xclick_ru_"], :root div[id^="join_informer_"], :root div[id^="itizergroup_"], :root div[id^="gnezdo_ru_"], :root div[id^="cpa_rotator_block"], :root div[id^="beroll_rotator"], :root div[id^="b_tz_"], :root div[id^="admixer-"], :root div[id^="DIV_DA_"], :root div[id^="Crt-"][style], :root div[data-server-rendered="true"] > div[id^="la-"], :root iframe[src^="https://a.adtng.com/"], :root div[class^="da-ya-widget"], :root div[class^="da-widget-"], :root div[class^="block_fortress"], :root div[class^="bidvol-widget-"], :root div[class*="td-a-rec-id-"], :root a[onclick*="trtkp.ru"], :root a[onclick*="offergate-amigo"], :root iframe[src*="litres.ru/static/widgets"], :root a[href^="https://www.juicer.io?referrer="], :root a[href^="https://relap.io/"][href*="promo_ad_link"], :root a[href^="https://msetup.pro"], :root a[href^="https://bongacams"][href*="com/track?"], :root a[href^="http://trafmaster.com"], :root a[href^="http://traderstart.mirtesen.ru"], :root a[href^="http://tds-2.ru"], :root a[href^="http://glprt.ru/affiliate/"], :root a[href^="http://datxxx.com"], :root a[href^="http://browserload.info/"], :root img[data-src="https://catalog.orbita.co.il/orbita.gif"], :root a[href^="/images/obmen/"][href$=".php"][target="_blank"], :root a[href^="/go/ufiler?"], :root a[href^="/go/ubar?"], :root a[href="http://advert.mirtesen.ru/"], :root a[href*="zdravo-med.ru"], :root a[href*="webdiana.ru/click"], :root a[href*="tvroff.net"], :root a[href*="tvks.ru"], :root a[href*="trklp.ru"], :root a[href*="traflabs.xyz"], :root div[id^="CGCandy"], :root a[href*="tptrk.ru"], :root a[href*="top.24smi.info"], :root a[href*="thor-media.ru/click/"], :root a[href*="shakespoint.com"], :root a[href*="shakesclick.com"], :root a[href*="shakescash.com"], :root a[href*="shakes.pro"], :root a[href*="sapmedia.ru"], :root a[href*="sandratand.ru"], :root a[href*="rexchange.begun.ru/rclick?"], :root a[href*="retagapp.com"], :root a[href*="refpazus.top"], :root [class^="tile-picker__CitrusBannerContainer-sc-"], :root a[href*="re-directme.com"], :root a[href^="https://homyanus.com"], :root a[href*="please-direct.me"], :root a[href*="://landingtracker.com/"], :root a[href*="offhealth.ru"], :root a[href*="lifebloggersz.ru"], :root a[href*="navaxudoru.com"], :root a[href*="m1cpl.ru"], :root div[id^="lazyad-"], :root a[href*="land-gooods.ru"], :root #root > .app .adfox-top, :root a[href*="idealmedia.io"], :root a[href*="joycasino.com/?partner="], :root a[href*="go.ad2up.com"], :root a[href*="//softboxik1.ru/"], :root a[href*="flylinks.pw"], :root [data-la-block-show-id], :root a[href*="films.ws"], :root .section-subheader > .section-hotel-prices-header, :root a[href*="feellights.ru"], :root a[href*="cmsmodnews.com"], :root a[href*="shakesin.com"], :root a[href*="bgrndi.com"], :root a[href*="amigo-biz.ru/ads/click"], :root a[href*="amgfile.ru"], :root a[href*="ads2-adnow.com"], :root a[href*="slovosil.com"], :root [class^="adDisplay-module"], :root a[href*="ads-provider.com"], :root a[href*="adpool.bet/"], :root a[href*="://www.meendoru.net/?partner="], :root a[href^="https://bs.serving-sys.com"], :root a[href*="://womens-journal.ru/"], :root a[href*="://vse-sdal.com/promo/"], :root [id^="ad-wrap-"], :root a[href^="https://go.tmrjmp.com"], :root a[href*="://ufiler-pro.ru/"], :root a[href*="://torrent-repa.site/"], :root a[href*="://topclicks.club/"], :root a[href*="://telamon"][href*="/tracker/?partner="], :root a[title="TopTracker.Ru - Рейтинг трекеров."], :root a[href*="://clickstats.fun/"], :root a[href*="://techdmn.com/"], :root [onclick*="traffic-media.co"], :root a[href*="://tatarkoresh.ru"], :root a[href*="://sugisatomi.com/"], :root a[href*="://softperehod.ru/"], :root a[href*="://segodnia.club/"], :root [href*="driverpack.io/"], :root a[href*="cpagetti1.com"], :root a[href*="://search-cdn.ru/r/"], :root a[href^="http://www.onclickmega.com/jump/next.php?"], :root a[href^="https://newbinotracs.com/"], :root a[href*="://ruprivate.club/"], :root a[href*="://ruonline.bar/"], :root a[href^="http://eaplay.ru/"], :root amp-connatix-player, :root a[href*="://riaccaw.com/"], :root [href^="https://join.playboyplus.com/track/"], :root a[href*="://reidancis.com/"], :root a[href*="://refpamjeql.top/"], :root a[href*="://r.advg.agency/"], :root a[href*="/onvix.tv/promo/"][target=_blank], :root a[href*="://premiumredir.ru/"], :root a[href*="://ourbrowser.net"], :root a[href*="://manysoftlink.ru/"], :root a[href^="http://static.fleshlight.com/images/banners/"], :root a[href*="://loderkkis.ru"], :root div[id^="advertur_"], :root .trc_related_container div[data-item-syndicated="true"], :root a[href*="://lapina.xyz/"], :root a[href*="://lapina.best/"], :root a[href*="://go.click2bit.net/"], :root a[href*="://go.bundlebyte.net/r/"], :root a[href*="://getbrauzer.ru/"], :root a[href*="://newbrowserme.ru/"], :root a[href*="://gertadv.ru/"], :root a[href*="torrentum.ru"], :root a[href*="://filesmytop.ru/"], :root [href^="https://www.mypillow.com/"] > img, :root a[href*="://fast2click.ru/"], :root a[href*="tvkw.ru"], :root a[href^="http://www.mrskin.com/tour"], :root a[href*="://etcodes.com/"], :root a[href*="://et-cod.com/"], :root a[href^="https://go.xxxjmp.com"], :root a[href*="://elgrur.com/"], :root a[href*="://doxod24.online/"], :root a[href*="://clickrpk.com/"], :root a[href*="://clickfrm.com/"], :root a[href*="://chikidiki.ru"], :root a[href*="://bubblevard.com/"], :root div[id^="adfox_"], :root a[href*="://bestnewsoft.ru/"], :root a[href*="://analyticsq.com"], :root a[href^="http://fly-shops.ru"], :root a[href*="/universal-lnk.net/"], :root a[href*="://getyoursoft.ru/"], :root a[href*="/sb/clk/"], :root a[href*="/rlink/simptizer/"], :root a[href^="https://go.247traffic.com/"], :root a[href*="://extlinka.ru/"], :root a[href*="/rapidtor.ru"], :root a[href*="/onvix.me/promo/"][target=_blank], :root a[href^="https://streamate.com/landing/click/"], :root a[href*="/newbrowser.club/"], :root a[href*="/myuniversalnk.com/"], :root a[href*="/mosday.ru/ad/"], :root a[href*="/loaderu.ru/"], :root a[href^="https://prime.rambler.ru/promo/"], :root a[href*="/installpack.net"], :root a[href*="/fastvk.com"], :root object[data*="ads.com/clk.swf"], :root a[href*="/eversaree.bid"], :root a[href*="://r.advmusic.com/"], :root a[href*="/clubleads.ru"], :root a[href*="/afftraf.co/"], :root a[href*="/advjump.com"], :root a[href*="://yadistr.ru/"], :root a[href*="//yojlf.com"], :root a[href^="https://taghaugh.com/"], :root a[href*="://installpack.ru"], :root a[href*="//viruniversal.com/"], :root a[href*="//universalut.info/"], :root a[href*="//universalini.info/"], :root a[href*="//universalie.info/"], :root a[href*="//ufiler-pro2.ru"], :root a[href*="//ubar.pro"], :root a[href*="//ubar-pro"], :root a[href*="/u-loads.ru/"], :root [href^="http://www.mypillow.com/"] > img, :root a[href*="//tranqvilius.com/"], :root div[data-adzone], :root a[href*="://tele.gg/"], :root a[href*="//tiruniversal.com/"], :root [href^="https://optimizedelite.com/"] > img, :root a[href*="//tdsrotate.ru/"], :root a[href^="http://d2.zedo.com/"], :root a[href*="//rotatemysoft.ru/"], :root a[href^="https://go.goasrv.com/"], :root a[href*="//restofarian.com"], :root a[href*="//reruniversal.com/"], :root a[href*="//portakamus.com/"], :root a[href^="https://go.nordvpn.net/aff"] > img, :root a[href*="//offergate.pro/"], :root a[href*="//newbrowser.me/"], :root a[href^="https://bongacams10.com/track?"], :root a[href*="//loderna.ru"], :root a[href^="https://tour.mrskin.com/"], :root a[href^="https://axdsz.pro/"], :root #BlWrapper > .b-temp_rbc, :root a[href*="//historategory.com/"], :root a[href*="//febrare.ru/"], :root a[href*="//givemysoft.ru/"], :root a[href*="//getmybrowser.ru/"], :root a[href*="://ya-distrib.ru/r/"], :root [href^="https://www.hostg.xyz/"] > img, :root a[href*="//gerocenius.com/"], :root [id^="ad_slider"], :root a[href^="http://adultfriendfinder.com/go/page/landing"], :root a[href*="advertwebgid.ru"], :root a[href*="//ext-load.net"], :root a[href*="://click2soft.ru/"], :root a[href*="//do-rod.com/"], :root a[href^="https://www.adskeeper.com"], :root a[href*="bestforexplmdb.com"], :root a[href*="/universalsrc.com/"], :root a[href^="https://azpresearch.club/"], :root a[href*="//bestonewos.com/"], :root a[href*="//avertise.ru/"], :root a[href*="//adretarget.net/"], :root div[id^="traffim-widget"], :root a[href^="https://m.do.co/c/"] > img, :root a[href*="//24smi."][href*="/top/"], :root a[href*=".ufiler.pro/"], :root a[href*="://topsofto.ru/"], :root [id^="unit_"] > a[href*="://smi2.net"], :root a[href*=".orgsales.ru"], :root [src^="//am15.net/?"], :root a[href*="://rendersaveron.com"], :root [id^="unit_"] > a[href*="://vrf.ru"], :root a[href*="//advtise.ru/"], :root .commercial-unit-mobile-top > div[data-pla="1"], :root a[href^="https://www.onlineusershielder.com/"], :root a[href*="/ber-ter.com"], :root [id^="newPortal_informer_"], :root [id^="n4p_"], :root #root > .app > .sticky-button, :root [href^="https://download.cdn.yandex.net/yandex-tag/weboffer/"], :root [href*="pigiuqproxy.com"], :root a[href*=".braun634.com/"], :root a[href*="media-rotate.com"], :root [href*="driftawayforfun.com"], :root a[href^="https://t.hrtye.com/"], :root [href*="://morelnk.ru/"], :root a[href*="mixadvert.com"], :root .card-captioned.crd > .crd--cnt > .s2nPlayer, :root a[href*="/ogclick.com/api/redirect"], :root [data-link*="://topclicks.club/"], :root [href*="://edgrmtracking.com/"], :root [href*="://clickpzk.com/"], :root [href*="://click.1k3web.com/"], :root a[href*="intovarro.ru"], :root [href*="/uni-tds.com/"], :root a[href^="http://go.xtbaffiliates.com/"], :root [data-link*="://ubar-pro"], :root .header-banner > #moneyback[target="_blank"], :root [data-link*="/sb/clk/"], :root [data-la-show-id], :root div[id^="zcbclk"], :root [data-la-custom-block], :root a[href*="herrabjec.pro"], :root [data-la-block], :root a[href^="https://fourwhenstatistics.com/"], :root [href*=".drp.su/"], :root div[id^="ad-div-"], :root [class^="flat_"][class*="_modal"], :root div[id^="adpartner-jsunit-"], :root a[href*="/yfiles1.ru"], :root a[href*="wow-partners.com/click.php"], :root [class^="flat_"][class*="_cross"], :root .content_rb[id^="content_rb_"], :root .base-page_center > .banerBottom, :root #adv_unisound ~ #main > #slidercontentContainer, :root a[href*="/get-torrent.ru"], :root #adv_kod_frame ~ #gotimer, :root a[href^="https://ad.zanox.com/ppc/"] > img, :root #MT_overroll ~ div[class][style="left:0px;top:0px;height:480px;width:650px;"], :root a[href*="//appt12mn.com/"], :root a[href*="kinqon.ru"], :root img[src*="://cp.beget.com/promo_data/"], :root zeus-ad, :root a[href*="problogrus.ru"], :root topadblock, :root a[href*="://offergate-apps-phkr.com/"], :root span[id^="ezoic-pub-ad-placeholder-"], :root guj-ad, :root gpt-ad, :root a[href^="https://go.trackitalltheway.com/"], :root div[jsdata*="CarouselPLA-"][data-id^="CarouselPLA-"], :root a[href*="//refpaewsbc.top/"], :root img[src*="//i.i.ua/r/"], :root [href="https://www.masstortfinancing.com/"] > img, :root div[id^="zergnet-widget"], :root img[src*="://r.i.ua/"], :root div[id^="yandex_ad"], :root div[id^="smi_teaser_"], :root div[id^="vuukle-ad-"], :root [href^="https://go.xlrdr.com"], :root div[id^="sticky_ad_"], :root a[href*="muz-loader.site"], :root a[href*="clickscloud.net"], :root div[id^="rc-widget-"], :root [href^="https://goldcometals.com/clk.trk"], :root a[href^="https://cams.imagetwist.com/in/?track="], :root div[id^="gpt_ad_"], :root div[id^="ezoic-pub-ad-"], :root div[id^="div-gpt-"], :root a[href*="fortedrow.pro"], :root a[href^="//a.bestcontentfare.top/"], :root div[id^="dfp-ad-"], :root div[id^="advads_ad_"], :root #root > .app .brand-widget__right-cl, :root div[id^="adspot-"], :root [class^="fpm_"][class*="_crss"], :root [href^="https://noqreport.com/"] > img, :root a[href*="://superiortds.ru/"], :root div[id^="ads300_250-widget-"], :root div[id^="ads300_100-widget-"], :root div[id^="ads250_250-widget-"], :root a[href*="trk-1.com"], :root div[id^="adrotate_widgets-"], :root div[id^="adngin-"], :root div[id^="_vdo_ads_player_ai_"], :root img[title="bigmir)net TOP 100"], :root div[id*="ScriptRoot"], :root div[id*="MarketGid"], :root div[data-native_ad], :root div[data-mini-ad-unit], :root div[data-insertion], :root div[data-id-advertdfpconf], :root a[href^="https://mediaserver.entainpartners.com/renderBanner.do?"], :root div[data-google-query-id], :root hl-adsense, :root div[data-contentexchange-widget], :root div[data-id^="div-gpt-ad-"], :root a[href*="//tekaners.com/"], :root div[data-content="Advertisement"], :root div[data-alias="300x250 Ad 2"], :root div[data-alias="300x250 Ad 1"], :root div[data-adunit], :root div[data-adunit-path], :root div[data-ad-wrapper], :root a[href*="//partners.house/"], :root [href^="http://join.michelle-austin.com/"], :root [id^="unit_"] > a[href*="://mirtesen.ru"], :root div[data-ad-targeting], :root div[data-ad-placeholder], :root a[href*="/go.1k3.net/"], :root div[class^="native-ad-"], :root a[href*="://shusnarmuk.com/"], :root div[data-dfp-id], :root div[class^="kiwi-ad-wrapper"], :root div[class^="Adstyled__AdWrapper-"], :root a[href^="https://trk.sportsflix4k.club/"], :root a[href^="https://go.ebrokerserve.com/"], :root div[aria-label="Ads"], :root display-ads, :root display-ad-component, :root [id^="relap-custom-iframe-rec"], :root aside[id^="adrotate_widgets-"], :root a[href*="//spishi.vip/"], :root article.ad, :root a[href*="ftpglst.com"], :root [data-name="adaptiveConstructorAd"], :root ark-top-ad, :root a[href^="https://ad.doubleclick.net/"], :root app-advertisement, :root [href^="https://shrugartisticelder.com"], :root [href^="http://globsads.com/"], :root a[href*="://folltiz.site/"], :root body > div[style="position: fixed; z-index: 999999; width: 400px; height: 308px; left: 5px; bottom: 5px;"], :root app-ad, :root a[href*="kma1.biz"], :root noindex > .search_result[class*="search_result_"], :root a[href^="https://go.xlvirdr.com"], :root amp-fx-flying-carpet, :root [href^="https://r.kraken.com/"], :root #PopWin[onmousemove], :root a[href*="//1xbetlk.site/"], :root amp-embed[type="taboola"], :root a[href*=".twkv.ru"], :root a[href*="//dagamah.com/"], :root [href^="https://antiagingbed.com/discount/"] > img, :root amp-ad-custom, :root ad-shield-ads, :root div[id^="div-ads-"], :root a[href*="://downloadbrowsernew.com/"], :root a[onmousedown^="this.href='https://paid.outbrain.com/network/redir?"][target="_blank"] + .ob_source, :root a[href*="beauty-list.ru"], :root iframe[src*="://goodgame.ru/html/embed-player/dist/index.html?partner="], :root citrus-ad-wrapper, :root img[src*="//counter.yadro.ru/"], :root [href^="https://awbbjmp.com/"], :root a[onmousedown^="this.href='https://paid.outbrain.com/network/redir?"][target="_blank"], :root a[data-redirect^="https://paid.outbrain.com/network/redir?"], :root a[href*="//12traffic.ru/"], :root a[href^="https://www.infowarsstore.com/"] > img, :root a[onmousedown^="this.href='http://paid.outbrain.com/network/redir?"][target="_blank"] + .ob_source, :root AD-TRIPLE-BOX, :root a[href^="https://yogacomplyfuel.com/"], :root a[class*="button"][href^="//"][href*="yandex"][onclick*="dnl"][onclick*="knopka"], :root a[href^="https://bngpt.com/"], :root a[href^="https://www.sheetmusicplus.com/"][href*="?aff_id="], :root [name^="google_ads_iframe"], :root a[href*="goext.info"], :root a[href*="://sdertjnbv.xyz/"], :root a[href^="https://www.purevpn.com/"][href*="&utm_source=aff-"], :root [href^="https://safer-redirection.com"], :root a[href^="https://www.mypornstarcams.com/landing/click/"], :root .commercial-unit-mobile-top .jackpot-main-content-container > .UpgKEd + .nZZLFc > .vci, :root a[href^="https://syndication.exoclick.com/"], :root a[href^="https://financeads.net/tc.php?"], :root a[href^="https://frameworkdeserve.com/"], :root a[href^="https://www.mrskin.com/tour"], :root a[href^="https://www.kingsoffetish.com/tour?partner_id="], :root a[href^="https://wittered-mainging.com/"], :root a[href^="https://t.grtyi.com/"], :root a[href^="https://www.highperformancecpmgate.com/"], :root a[href*="ex.24smi.info"], :root a[href^="https://www.highcpmrevenuenetwork.com/"], :root a[class*="button"][href^="/go/"][href*="visitid"][onclick*="dnl"], :root a[href^="https://www.get-express-vpn.com/offer/"], :root a[href^="http://www.friendlyduck.com/AF_"], :root a[href^="https://www.financeads.net/tc.php?"], :root .mywidget__col > .mywidget__link_advert, :root a[href^="https://www.brazzersnetwork.com/landing/"], :root div[class^="Display_displayAd"], :root [href^="https://mypillow.com/"] > img, :root a[href^="https://www.sheetmusicplus.com/?aff_id="], :root a[href^="https://www.bang.com/?aff="], :root a[href*="://clickstats.online/"], :root [href^="https://www.targetingpartner.com/"], :root a[href^="https://www.adxsrve.com/"], :root [href^="https://track.fiverr.com/visit/"] > img, :root [data-template-type="nativead"], :root a[href*="/myuniversalnk.net/"], :root a[href^="https://www.adultempire.com/"][href*="?partner_id="], :root a[href^="https://webroutetrk.com/"], :root a[href*="://go.btraffic.net/"], :root div[class^="cnt32_"][id^="cnt_rb_"], :root a[href^="https://twinrdsyn.com/"], :root [class^="fpm_"][class*="_out"], :root a[href^="https://tsartech.g2afse.com/"], :root [href^="https://www.mypatriotsupply.com/"] > img, :root a[href^="https://adswick.com/"], :root a[href^="https://trk.softonixs.xyz/"], :root [href*="://simpalsid.com/ad/click?id"], :root a[href*=".pokupkins.ru"], :root a[href^="https://trk.nfl-online-streams.club/"], :root [href^="https://turtlebids.irauctions.com/"] img, :root a[href^="https://tracking.avapartner.com/"], :root a[href^="https://track.afcpatrk.com/"], :root a[href*="https://relap.io/r?"], :root a[href^="https://traffic.bannerator.com/"], :root a[href^="https://track.adform.net/"], :root a[href*="goodtrack.ru"], :root a[href^="https://torguard.net/aff.php"] > img, :root div[data-adname], :root a[href^="https://thechleads.pro/"], :root div[id^="criteo-"][style], :root a[href*="://cozibaneco.com/"], :root a[href*="://edugrampromo.com/"], :root [data-role="tile-ads-module"], :root a[href^="https://adsrv4k.com/"], :root a[href^="https://go.xlviirdr.com"], :root a[href^="https://thaudray.com/"], :root a[href^="https://www.5mno3.com/"], :root a[href^="https://click.candyoffers.com/"], :root [href^="https://zstacklife.com/"] img, :root a[href^="https://t.aslnk.link/"], :root a[href^="https://t.adating.link/"], :root iframe[src*="tureckiy-serial.ru/"][src$=".php"], :root a[href^="https://syndication.dynsrvtbg.com/"], :root div[class*="relap"][class*="-rec-item"], :root a[href^="https://static.fleshlight.com/images/banners/"], :root [src*="mixadvert.com"], :root [onclick*="msetup"][onclick*="partner"][onclick*="utm_"], :root a[href^="https://go.strpjmp.com/"], :root a[href^="https://refpa4903566.top/"], :root div[id^="ads_games_"], :root a[href^="https://prf.hn/click/"][href*="/camref:"] > img, :root a[href^="https://serve.awmdelivery.com/"], :root a[href^="https://prf.hn/click/"][href*="/adref:"] > img, :root div[id^="M"][id*="Composite"], :root a[href^="https://mmwebhandler.aff-online.com/"], :root a[href^="https://www.bet365.com/"][href*="affiliate="], :root a[href*="litewebbusiness.com"], :root iframe[id^="marketgid_"], :root a[onclick*="n284adserv.com"], :root a[href^="https://pb-track.com/"], :root a[href^="https://paid.outbrain.com/network/redir?"], :root div[id^="ad_position_"], :root a[href^="https://ovb.im/"], :root a[href^="https://natour.naughtyamerica.com/track/"], :root a[href*="//adoffer.pro/"], :root [href^="https://stvkr.com/"], :root [href^="https://freecourseweb.com/"] > .sitefriend, :root [href^="https://www.herbanomic.com/"] > img, :root div[id^="bidvol-widget-"], :root [href^="http://go.cm-trk2.com/"], :root a[href*="://kinobud.site/"], :root a[href^="https://maymooth-stopic.com/"], :root a[href^="https://loboclick.com"], :root [href^="https://routewebtk.com/"], :root a[href^="https://see.kmisln.com/"], :root .trc_rbox .syndicatedItem, :root a[href^="https://a.bestcontentweb.top/"], :root a[href^="https://lobimax.com/"], :root a[href^="https://go.xxxijmp.com"], :root a[href^="https://lead1.pl/"], :root a[href*="katuhus.com"], :root a[data-href*="recreativ.ru"], :root iframe[src*="zhitomir.info/price"], :root a[href^="https://refpa.top/"], :root a[href^="https://landing.brazzersnetwork.com/"], :root a[href^="https://ads.leovegas.com/redirect.aspx?"], :root [class^="fpm_"][class*="_modal"], :root a[href^="https://land.brazzersnetwork.com/landing/"], :root a[href^="https://juicyads.in/"], :root [href*="://click.1k3web.net/"], :root a[href^="https://aweptjmp.com/"], :root a[href^="https://itubego.com/video-downloader/?affid="], :root a[href^="https://iqbroker.com/"][href*="?aff="], :root a[href*="trtkp.ru"], :root a[href*="//fofuvipibo.com/"], :root [href^="http://join.shemalepornstar.com/"], :root [id^="ad_sky"], :root a[href^="https://incisivetrk.cvtr.io/click?"], :root [data-revive-zoneid], :root a[href^="https://googleads.g.doubleclick.net/pcs/click"], :root a[href*="//universalse.info/"], :root a[href^="http://click.hotlog.ru/"], :root a[href^="https://clk.wrenchsound.store/"], :root a[href^="https://go.zybrdr.com"], :root div[style*="am15.net/img/player_skins"], :root a[href^="https://go.xxxiijmp.com"], :root a[href^="https://mityneedn.com/"], :root a[href*="://softclicks.ru/"], :root a[href^="https://go.xtbaffiliates.com/"], :root [alt="Rambler's Top100"], :root a[href^="https://ismlks.com/"], :root [href*="://drp.su/"], :root a[href^="https://go.xlirdr.com"], :root a[href^="https://go.xlviiirdr.com"], :root [data-css-class="dfp-inarticle"], :root a[href*="://getfiletds.ru/"], :root a[href^="https://go.skinstrip.net"][href*="?campaignId="], :root a[href^="https://go.markets.com/visit/?bta="], :root a[href^="https://billing.purevpn.com/aff.php"] > img, :root a[href^="https://go.hpyrdr.com/"], :root a[href^="https://go.goaserv.com/"], :root a[href^="http://reals-story.ru/"], :root a[href^="https://track.wg-aff.com"], :root a[href^="https://go.dmzjmp.com"], :root a[href^="https://twinrdsrv.com/"], :root a[href*="makegreat.website"], :root body.has-brand .b-content__main > div[style^="height: 250px; overflow: hidden;"], :root a[href^="https://go.admjmp.com/"], :root a[href*="browser-ru.site"], :root a[href^="https://www.nutaku.net/signup/landing/"], :root [href^="https://kingered-banctours.com/"], :root a[href^="https://get.surfshark.net/aff_c?"][href*="&aff_id="] > img, :root [href^="https://affiliate.fastcomet.com/"] > img, :root a[href*="//universalice.info/"], :root a-ad, :root a[href^="http://amigodistr.ru/"], :root a[href^="https://affiliate.rusvpn.com/click.php?"], :root a[href^="https://geniusdexchange.com/"], :root a[href^="https://flirtandsweets.life/"], :root a[href^="https://www.mrskin.com/account/"], :root a[href^="https://go.xlivrdr.com"], :root bottomadblock, :root a[href^="https://fertilitycommand.com/"], :root [data-freestar-ad], :root a[href^="https://fc.lc/ref/"], :root [href^="https://traffserve.com/"], :root [data-href^="https://download.cdn.yandex.net/yandex-tag/weboffer/"], :root a[href^="https://click.hoolig.app/"], :root div[data-native-ad], :root a[href^="https://engine.trackingdesks.com/"], :root a[href*="/uni-lnk.com/"], :root a[href*="://vpnbrowser.ru/"], :root a[href*="/onvix.co/promo/"][target=_blank], :root .trc_rbox_div .syndicatedItemUB, :root [href^="https://totlnkcl.com/"], :root a[href^="https://bongacams2.com/track?"], :root [href^="https://www.reimageplus.com/"], :root a[href*="tdstrk.ru"], :root a[href^="https://engine.phn.doublepimp.com/"], :root a[href*="please-direct.com"], :root a[href^="https://engine.blueistheneworanges.com/"], :root a[href*="/sarimsolus.com/"], :root div[id^="admixer_"], :root a[href^="https://wantopticalfreelance.com/"], :root a[href^="https://dl-protect.net/"], :root [onclick*="content.ad/"], :root a[href^="https://clixtrac.com/"], :root a[href^="https://mediaserver.gvcaffiliates.com/renderBanner.do?"], :root [href*="://click.1k3pub.com/"], :root a[href^="https://join.dreamsexworld.com/"], :root a[href*="://clickstats.pw/"], :root a[href^="https://click.linksynergy.com/fs-bin/"], :root [href^="https://wct.link/"], :root a[href^="https://track.totalav.com/"], :root img[src^="https://images.purevpnaffiliates.com"], :root a[href^="https://porntubemate.com/"], :root a[href^="http://www.gfrevenge.com/landing/"], :root body > iframe[style^="position"][style*="fixed"][id^="iFb"][src^="/?"], :root .ob_container .item-container-obpd, :root a[href^="https://clickadilla.com/"], :root div[class^="yandex_rtb"], :root a[href*="://searchlnk.ru/r/"], :root a[href^="https://click.dtiserv2.com/"], :root a[href*="://yasearchcdn.ru/r/"], :root a[href*="/vkout.ru"], :root a[href^="https://claring-loccelkin.com/"], :root a[href*="/uloads.ru/"], :root #root > .app .adfox, :root [class^="s2nPlayer"], :root iframe[src*="//refpakglscpj."], :root a[href^="http://olivka.biz/"], :root [data-ad-cls], :root a[href^="https://chaturbate.jjgirls.com/?track="], :root a[href*="//universalin.info/"], :root a[href*="kodielinktrust.ru"], :root iframe[src*="://rstbtmd.com/"], :root a[href^="http://www.onwebcam.com/random?t_link="], :root a[href*="://101partners-stat2.com/"], :root a[href^="https://www.nudeidols.com/cams/"], :root a[href^="https://chaturbate.com/in/?track="], :root iframe[src*="laim.tv/rotator/"], :root a[href*="/advertisesimple.info"], :root a[href*="//loderla.online"], :root .base-page_center > .banerTopOver, :root a[href^="https://chaturbate.com/in/?tour="], :root a[href^="https://cam4com.go2cloud.org/"], :root a[href^="https://bluedelivery.pro/"], :root #topstuff > #tads, :root a[href^="https://black77854.com/"], :root a[href^="http://adultgames.xxx/"], :root a[href*="homework.ru/?partnerId="], :root a[href^="https://ndt5.net/"], :root [href*="postlnk.com"], :root a[href^="https://a2.adform.net/"], :root a[href^="https://batheunits.com/"], :root iframe[src*="fwdcdn.com/frame/partners/"], :root a[target="_blank"][onmousedown="this.href^='http://paid.outbrain.com/network/redir?"], :root [data-dynamic-ads], :root a[href^="https://banners.livepartners.com/"], :root a[href*="gpclick.ru"], :root [href="https://masstortfinancing.com"] img, :root a[href^="http://luckiestclick.com/goto."], :root [class^="fpm_"][class*="_cross"], :root a[href^="https://albionsoftwares.com/"], :root a[href^="https://fleshlight.sjv.io/"], :root a[href^="https://go.etoro.com/"] > img, :root a[href*="/universalsrc.net/"], :root [href="https://ourgoldguy.com/contact/"] img, :root a[href^="https://join.sexworld3d.com/track/"], :root div[id*="Teaser_Block"], :root a[href^="https://intenseaffiliates.com/redirect/"], :root a[href^="https://ads.ad4game.com/"], :root a[href*="/rapidtor.site"], :root a[href^="http://partners.etoro.com/"], :root [id^="google_ads_iframe"], :root iframe[title="mixAd"], :root DIV[id^="DIV_NNN_"], :root a[href^="https://syndication.optimizesrv.com/"], :root a[href^="https://affpa.top/"], :root a[href^="https://go.gldrdr.com/"], :root a[href^="https://adnetwrk.com/"], :root a[href^="https://adjoincomprise.com/"], :root a[href*="xxxrevpushclcdu.com"], :root [href^="http://misslinkvocation.com/"], :root a[href^="https://adclick.g.doubleclick.net/"], :root a[href*="://ufiler-download.ru/"], :root a[href^="https://landing1.brazzersnetwork.com"], :root a[href^="https://a.bestcontentoperation.top/"], :root div[id^="smi2adblock_"], :root [data-m-ad-id], :root .commercial-unit-mobile-top .jackpot-main-content-container > .UpgKEd + .nZZLFc > div > .vci, :root a[href^="https://a-ads.com/"], :root div[id^="news_nest_msk_ru"], :root a[href^="https://brightadnetwork.com/"], :root [id^="unit_"] > a[href*="://smi2.ru"], :root .base-page_left-side > #left_ban, :root [href^="https://www.avantlink.com/click.php"] img, :root a[href^="https://awentw.com/"], :root a[href^="https://www.googleadservices.com/pagead/aclk?"], :root [class^="flat_"][class*="_crss"], :root a[href*="netcrys.com"], :root a[href*="//utimg.ru/"], :root a[href^="https://agacelebir.com/"], :root a[href^="https://spygasm.com/track?"], :root a[href^="http://cam4com.go2cloud.org/aff_c?"], :root #adv_unisound ~ #ad_module_cont > [id^="ad_module"], :root a[href^="https://ad.kubiccomps.icu/"], :root [data-desktop-ad-id], :root a[href*="/kshop3.biz"], :root a[href^="https://k2s.cc/pr/"], :root a[href^="http://trk.globwo.online/"], :root a[href^="https://prf.hn/click/"][href*="/creativeref:"] > img, :root a[href^="http://www.adultempire.com/unlimited/promo?"][href*="&partner_id="], :root a[href^="http://traffic.tc-clicks.com/"], :root a[href^="http://tour.mrskin.com/"], :root iframe[src*="utraff.com"], :root a[href^="https://join.virtualtaboo.com/track/"], :root a[href*="cpl1.ru"], :root a[href^="https://funkydaters.com/"], :root a[href^="http://https://www.get-express-vpn.com/offer/"], :root [href^="https://glersakr.com/"], :root a[href*="://tdsrotations.ru/"], :root div[id^="google_dfp_"], :root a[href^="http://googleads.g.doubleclick.net/pcs/click"], :root .rc-cta[data-target], :root a[href^="http://click.payserve.com/"], :root #mgb-container > #mgb, :root a[href^="https://porngames.adult/?SID="], :root [href^="http://clicks.totemcash.com/"], :root div[data-adv-type="dfp"], :root a[href^="https://misspkl.com/"], :root a[href*="://ya-cdn.ru/r/"], :root #slashboxes > .deals-rail, :root a[href*="trafgid.xyz"], :root a[href*="://getyousoft.ru/"], :root [onclick*="/sb/clk/"], :root [href^="https://www.brighteonstore.com/products/"] img, :root a[href^="http://bc.vc/?r="], :root a[href*="://dmtech05.com/"], :root [href^="http://homemoviestube.com/"], :root a[href^="http://ad.doubleclick.net/"], :root a[href*="kshop2.biz"], :root a[href^="https://a.adtng.com/"], :root a[href^="//pubads.g.doubleclick.net/"], :root a[href*="twtn.ru/"], :root [data-d-ad-id], :root a[href*=".engine.adglare.net/"], :root a[href*="ultrabit.ws"], :root a[data-widget-outbrain-redirect^="http://paid.outbrain.com/network/redir?"], :root a[href*="://new.torrent-pack.ru/"], :root [href*="//loadbrowser.ru/"], :root [data-ad-width], :root a[href*="://adv-views.com"], :root a[data-url^="http://paid.outbrain.com/network/redir?"] + .author, :root a[href^="http://bodelen.com/"], :root a[data-oburl^="https://paid.outbrain.com/network/redir?"], :root [href^="https://cpa.10kfreesilver.com/"], :root a[href^="https://a.bestcontentfood.top/"], :root a[href*="//lkstrck2.com/"], :root a[href^="https://reinstandpointdumbest.com/"], :root .base-page_container > .banerRight, :root a[href*="lifenews24x7.ru"], :root a[data-obtrack^="http://paid.outbrain.com/network/redir?"], :root img[src*="top.mail.ru/counter?"], :root a[href^="http://wct.link/"], :root div[id^="ad-position-"], :root [href^="https://goldforyourfuture.com/clk.trk"] img, :root [href^="https://infinitytrk.com/"], :root [onclick*="//msetup.pro/"], :root [onclick^="location.href='http://www.reimageplus.com"], :root [id^="section-ad-banner"], :root a[href^="https://go.julrdr.com/"], :root [href^="https://zone.gotrackier.com/"], :root a[href*="://clickbytes.ru/"], :root a[href*=".adsbid.ru"], :root [href^="https://detachedbates.com/"], :root a[href*="//loderls.ru"], :root [href^="https://www.restoro.com/"], :root a[href^="https://www.goldenfrog.com/vyprvpn?offer_id="][href*="&aff_id="], :root a[href^="https://fastestvpn.com/lifetime-special-deal?a_aid="], :root a[href^="http://affiliate.glbtracker.com/"], :root a[href^="https://leg.xyz/?track="], :root div[id^="crt-"][style], :root [href^="https://shiftnetwork.infusionsoft.com/go/"] > img, :root a[onmousedown^="this.href='http://paid.outbrain.com/network/redir?"][target="_blank"], :root [href^="https://secure.bmtmicro.com/servlets/"], :root a[href*="//webbrowser.club/"], :root .pip-video-wrapper > .pip-video-label, :root iframe[src*="traffic-media.co"], :root a[href^="https://losingoldfry.com/"], :root .scroll-fixable.rail-right > .deals-rail, :root a[href^="https://oackoubs.com/"], :root [onclick*=".twkv.ru"], :root a[href^="https://awptjmp.com/"], :root .commercial-unit-mobile-top > .v7hl4d, :root [href^="http://mypillow.com/"] > img, :root #kt_player > a[target="_blank"], :root a[href^="https://camfapr.com/landing/click/"], :root a[href^="http://bongacams.com/track?"], :root [data-ad-manager-id], :root a[href^="https://promo-bc.com/"], :root a[href^="https://clicks.pipaffiliates.com/"], :root [href*="://browseit.ru/"], :root a[href^="https://go.hpyjmp.com"], :root a[href^="https://adserver.adreactor.com/"], :root ADS-RIGHT, :root a[href*=".trust.zone"], :root [href^="https://mystore.com/"] > img, :root [href^="https://mypatriotsupply.com/"] > img, :root iframe[src*="://partner-widget.vse-sdal.com/"], :root [href^="https://mylead.global/stl/"] > img, :root [onclick*="mixadvert.com"], :root #leader-companion > a[href], :root a[onclick*="/link-fes.ru"], :root a[href^="https://transfer.xe.com/signup/track/redirect?"], :root .vid-present > .van_vid_carousel__padding, :root a[href*="://filetaker.ru/"], :root a[href*="//sub"][href*="bubblesmedia."], :root [href^="https://istlnkcl.com/"], :root [href^="https://ilovemyfreedoms.com/landing-"], :root [href^="https://go.affiliatexe.com/"], :root [href^="https://go.4rabettraff.com/"], :root a[href^="https://go.cmtaffiliates.com/"], :root a[href^="https://tm-offers.gamingadult.com/"], :root a[href^="http://kshop.biz/"], :root [href^="https://charmingdatings.life/"], :root a[href*="linkmyc.com"], :root a[href^="https://kshop"][href*=".pro/"], :root ins.adsbygoogle, :root a[href^="https://1startfiledownload1.com/"], :root [data-la-show-block-id], :root .trc_rbox_border_elm .syndicatedItem, :root a[href^="http://adf.ly/?id="], :root [href^="https://engine.gettopple.com/"], :root [data-id^="div-gpt-ad"], :root a[href*="turbotraf.com"], :root [href^="https://affect3dnetwork.com/track/"], :root [href="//sexcams.plus/"], :root a[href*="://go.progfile.space/r/"], :root a[href^="https://go.currency.com/"], :root [onclick*="trklp.ru"], :root [href^="https://rapidgator.net/article/premium/ref/"], :root a[href^="https://www.sugarinstant.com/?partner_id="], :root a[href^="https://adultfriendfinder.com/go/page/landing"], :root [href^="https://join3.bannedsextapes.com"], :root div[data-spotim-slot], :root [class^="flat_"][class*="_out"], :root a[href^="http://apytrc.com/click/"], :root [href^="https://join.girlsoutwest.com/"], :root a[href*="://downloadcontent2.ru/"], :root [href^="http://trafficare.net/"], :root a[href*="//universalies.info/"], :root a[href^="https://tc.tradetracker.net/"] > img, :root a[href*="//go.webredir.net/r/"], :root [href^="http://join.shemalesfromhell.com/"], :root .plistaList > .itemLinkPET, :root a[href^="http://www.adultdvdempire.com/?partner_id="][href*="&utm_"], :root #root > .app .partner-block-wrapper, :root div[class*="spklw"][data-type="ad"], :root [href^="http://join.shemale.xxx/"], :root a[href^="https://ads.betfair.com/redirect.aspx?"], :root [href^="http://www.fleshlightgirls.com/"], :root [href^="http://join.trannies-fuck.com/"], :root [data-adblockkey], :root a[href*="filebase.me"], :root a[href^="https://cpmspace.com/"], :root a[href^="https://thefacux.com/"], :root a[href^="https://ads.planetwin365affiliate.com/redirect.aspx?"], :root div[class^="mixadvert"], :root [href^="http://join.rodneymoore.com/"], :root a[href^="https://www.privateinternetaccess.com/"] > img, :root [href*="/vaigowoa.com"], :root a[href*="://rotationlinks.ru/"], :root a[href*="awesomeredirector"], :root div[recirculation-ad-container], :root a[href*="://parandaya.com"], :root a[href*="//loderlx.ru"], :root [id^="div-gpt-ad"], :root [href^="https://ad.admitad.com/"], :root [data-advadstrackid], :root a[href^="https://u.expresstech.io/"], :root [href="https://jdrucker.com/gold"] > img, :root [href^="https://v.investologic.co.uk/"], :root [href^="https://cipledecline.buzz/"], :root a[href^="https://track.ultravpn.com/"], :root [href^="https://fancentro.com/"], :root a[href*="://mysoftrotate.ru/"], :root [data-mobile-ad-id], :root a[href^="http://tc.tradetracker.net/"] > img, :root a[href^="https://www.geekbuying.com/dynamic-ads/"], :root a[href^="http://affiliates.thrixxx.com/"], :root a[href*="://betahit.click/"], :root #searchResultsList > div > div[onclick$="'inline.ad'});"], :root a[href*="gocdn.ru"], :root AMP-AD, :root .base-page_center > .banerTop, :root a[href*="://z.cdn.traffic"][href*="/load"], :root a[href*="://dafeb.ru/"], :root div[id^="taboola-stream-"], :root [href^="https://go.astutelinks.com/"], :root [class^="amp-ad-"], :root a[href*="/api/redirect?offerid="], :root a[href*="/universallnk.net/"], :root .grid > .container > #aside-promotion, :root DFP-AD, :root a[href*="nhebd.xyz"], :root AD-SLOT, :root a[href*="//parandeya.com/"], :root [data-url*="://installpack.net"], :root .ob_dual_right > .ob_ads_header ~ .odb_div, :root [href^="https://click2cvs.com/"], :root img[src*="cycounter"][width="88"][height="31"], :root .trc_rbox_div .syndicatedItem, :root app-large-ad, :root a[href^="https://iactrivago.ampxdirect.com/"], :root a[href^="https://a.medfoodhome.com/"], :root [data-ad-module], :root [href^="https://trackfin.asia/"], :root .plistaList > .plista_widget_underArticle_item[data-type="pet"], :root a[href^="https://startgAming.net/tienda/"], :root a[href^="http://putanapartners.com/go."], :root atf-ad-slot, :root a[href*="sviruniversal.com/"], :root a[href*="octoclick.net"], :root #atvcap + #tvcap > .mnr-c > .commercial-unit-mobile-top, :root a[href^="https://traffdaq.com/"], :root [data-la-refresh-timeout], :root [class^="div-gpt-ad"], :root a[href*="//refpabjgth.top/"], :root [href^="http://residenceseeingstanding.com/"], :root [href^="https://www.cloudways.com/en/?id"], :root a[href^="https://refpazkjixes.top/"], :root a[href*="://takenewsoft.ru/"], :root a[href^="https://join.virtuallust3d.com/"], :root a[href*="cpl11.ru"], :root #taw > .med + div > #tvcap > .mnr-c:not(.qs-ic) > .commercial-unit-mobile-top, :root [data-ez-name] { display: none !important; }
                                    </style>
                                    <style id="INLINE_PEN_STYLESHEET_ID">
                                        /* Please ❤ this if you like it! */


    @import url('https://fonts.googleapis.com/css?family=Poppins:400,500,600,700,800,900');

    body{
     font-family: 'Poppins', sans-serif;
     font-weight: 300;
     font-size: 15px;
     line-height: 1.7;
     color: #c4c3ca;
     background-color: #1f2029;
     overflow-x: hidden;
   }
   a {
     cursor: pointer;
     transition: all 200ms linear;
   }
   a:hover {
     text-decoration: none;
   }
   .link {
    color: #c4c3ca;
  }
  .link:hover {
    color: #ffeba7;
  }
  p {
    font-weight: 500;
    font-size: 14px;
    line-height: 1.7;
  }
  h4 {
    font-weight: 600;
  }
  h6 span{
    padding: 0 20px;
    text-transform: uppercase;
    font-weight: 700;
  }
  .section{
    position: relative;
    width: 100%;
    display: block;
  }
  .full-height{
    min-height: 100vh;
  }
  [type="checkbox"]:checked,
  [type="checkbox"]:not(:checked){
    position: absolute;
    left: -9999px;
  }
  .checkbox:checked + label,
  .checkbox:not(:checked) + label{
    position: relative;
    display: block;
    text-align: center;
    width: 60px;
    height: 16px;
    border-radius: 8px;
    padding: 0;
    margin: 10px auto;
    cursor: pointer;
    background-color: #ffeba7;
  }
  .checkbox:checked + label:before,
  .checkbox:not(:checked) + label:before{
    position: absolute;
    display: block;
    width: 36px;
    height: 36px;
    border-radius: 50%;
    color: #ffeba7;
    background-color: #102770;
    font-family: 'unicons';
    content: '\eb4f';
    z-index: 20;
    top: -10px;
    left: -10px;
    line-height: 36px;
    text-align: center;
    font-size: 24px;
    transition: all 0.5s ease;
  }
  .checkbox:checked + label:before {
    transform: translateX(44px) rotate(-270deg);
  }


  .card-3d-wrap {
    position: relative;
    width: 440px;
    max-width: 100%;
    height: 400px;
    -webkit-transform-style: preserve-3d;
    transform-style: preserve-3d;
    perspective: 800px;
    margin-top: 60px;
  }
  .card-3d-wrapper {
    width: 100%;
    height: 100%;
    position:absolute;    
    top: 0;
    left: 0;  
    -webkit-transform-style: preserve-3d;
    transform-style: preserve-3d;
    transition: all 600ms ease-out; 
  }
  .card-front, .card-back {
    width: 100%;
    height: 100%;
    background-color: #2a2b38;
    background-image: url('https://s3-us-west-2.amazonaws.com/s.cdpn.io/1462889/pat.svg');
    background-position: bottom center;
    background-repeat: no-repeat;
    background-size: 300%;
    position: absolute;
    border-radius: 6px;
    left: 0;
    top: 0;
    -webkit-transform-style: preserve-3d;
    transform-style: preserve-3d;
    -webkit-backface-visibility: hidden;
    -moz-backface-visibility: hidden;
    -o-backface-visibility: hidden;
    backface-visibility: hidden;
  }
  .card-back {
    transform: rotateY(180deg);
  }
  .checkbox:checked ~ .card-3d-wrap .card-3d-wrapper {
    transform: rotateY(180deg);
  }
  .center-wrap{
    position: absolute;
    width: 100%;
    padding: 0 35px;
    top: 50%;
    left: 0;
    transform: translate3d(0, -50%, 35px) perspective(100px);
    z-index: 20;
    display: block;
  }


  .form-group{ 
    position: relative;
    display: block;
    margin: 0;
    padding: 0;
  }
  .form-style {
    padding: 13px 20px;
    padding-left: 55px;
    height: 48px;
    width: 100%;
    font-weight: 500;
    border-radius: 4px;
    font-size: 14px;
    line-height: 22px;
    letter-spacing: 0.5px;
    outline: none;
    color: #c4c3ca;
    background-color: #1f2029;
    border: none;
    -webkit-transition: all 200ms linear;
    transition: all 200ms linear;
    box-shadow: 0 4px 8px 0 rgba(21,21,21,.2);
  }
  .form-style:focus,
  .form-style:active {
    border: none;
    outline: none;
    box-shadow: 0 4px 8px 0 rgba(21,21,21,.2);
  }
  .input-icon {
    position: absolute;
    top: 0;
    left: 18px;
    height: 48px;
    font-size: 24px;
    line-height: 48px;
    text-align: left;
    color: #ffeba7;
    -webkit-transition: all 200ms linear;
    transition: all 200ms linear;
  }

  .form-group input:-ms-input-placeholder  {
    color: #c4c3ca;
    opacity: 0.7;
    -webkit-transition: all 200ms linear;
    transition: all 200ms linear;
  }
  .form-group input::-moz-placeholder  {
    color: #c4c3ca;
    opacity: 0.7;
    -webkit-transition: all 200ms linear;
    transition: all 200ms linear;
  }
  .form-group input:-moz-placeholder  {
    color: #c4c3ca;
    opacity: 0.7;
    -webkit-transition: all 200ms linear;
    transition: all 200ms linear;
  }
  .form-group input::-webkit-input-placeholder  {
    color: #c4c3ca;
    opacity: 0.7;
    -webkit-transition: all 200ms linear;
    transition: all 200ms linear;
  }
  .form-group input:focus:-ms-input-placeholder  {
    opacity: 0;
    -webkit-transition: all 200ms linear;
    transition: all 200ms linear;
  }
  .form-group input:focus::-moz-placeholder  {
    opacity: 0;
    -webkit-transition: all 200ms linear;
    transition: all 200ms linear;
  }
  .form-group input:focus:-moz-placeholder  {
    opacity: 0;
    -webkit-transition: all 200ms linear;
    transition: all 200ms linear;
  }
  .form-group input:focus::-webkit-input-placeholder  {
    opacity: 0;
    -webkit-transition: all 200ms linear;
    transition: all 200ms linear;
  }

  .btn{  
    border-radius: 4px;
    height: 44px;
    font-size: 13px;
    font-weight: 600;
    text-transform: uppercase;
    -webkit-transition : all 200ms linear;
    transition: all 200ms linear;
    padding: 0 30px;
    letter-spacing: 1px;
    display: -webkit-inline-flex;
    display: -ms-inline-flexbox;
    display: inline-flex;
    -webkit-align-items: center;
    -moz-align-items: center;
    -ms-align-items: center;
    align-items: center;
    -webkit-justify-content: center;
    -moz-justify-content: center;
    -ms-justify-content: center;
    justify-content: center;
    -ms-flex-pack: center;
    text-align: center;
    border: none;
    background-color: #ffeba7;
    color: #102770;
    box-shadow: 0 8px 24px 0 rgba(255,235,167,.2);
  }
  .btn:active,
  .btn:focus{  
    background-color: #102770;
    color: #ffeba7;
    box-shadow: 0 8px 24px 0 rgba(16,39,112,.2);
  }
  .btn:hover{  
    background-color: #102770;
    color: #ffeba7;
    box-shadow: 0 8px 24px 0 rgba(16,39,112,.2);
  }




  .logo {
   position: absolute;
   top: 30px;
   right: 30px;
   display: block;
   z-index: 100;
   transition: all 250ms linear;
 }
 .logo img {
   height: 26px;
   width: auto;
   display: block;
 }
                                    </style>
                                </link>
                            </link>
                        </link>
                    </link>
                </link>
            </meta>
        </meta>
    </head>
    <body>
        <div class="section">
            <div class="container">
                <div class="row full-height justify-content-center">
                    <div class="col-12 text-center align-self-center py-5">
                        <div class="section pb-5 pt-5 pt-sm-2 text-center">
                            <h6 class="mb-0 pb-3">
                                <span>
                                    Log In
                                </span>
                                <span>
                                    Sign Up
                                </span>
                            </h6>
                            <input class="checkbox" id="reg-log" name="reg-log" type="checkbox">
                                <label for="reg-log">
                                </label>
                                <div class="card-3d-wrap mx-auto">
                                    <div class="card-3d-wrapper">
                                        <div class="card-front">
                                            <div class="center-wrap">
                                                <div class="section text-center">
                                                    <h4 class="mb-4 pb-3">
                                                        Вхід
                                                    </h4>
                                                    <form action="cabinet/auth.php" id="auth-form" method="post" name="auth-form">
                                                        <div class="form-group">
                                                            <input autocomplete="off" class="form-style" id="auth-login" name="auth-login" placeholder="Логін" type="login">
                                                                <i class="input-icon uil uil-at">
                                                                </i>
                                                            </input>
                                                        </div>
                                                        <div class="form-group mt-2">
                                                            <input autocomplete="off" class="form-style" id="auth-password" name="auth-password" placeholder="Пароль" type="password">
                                                                <i class="input-icon uil uil-lock-alt">
                                                                </i>
                                                            </input>
                                                        </div>
                                                        <input class="btn mt-4" id="auth-submit" name="auth-submit" type="submit" value="Увійти">
                                                            <p class="mb-0 mt-4 text-center">
                                                                <a class="link">
                                                                    Забули пароль?
                                                                </a>
                                                            </p>
                                                        </input>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="card-back">
                                            <div class="center-wrap">
                                                <div class="section text-center">
                                                    <h4 class="mb-4 pb-3">
                                                        Реєстрація
                                                    </h4>
                                                    <form action="cabinet/sign-up.php" id="sign-up-form" method="post" name="sign-up-form">
                                                        <div class="form-group">
                                                            <input autocomplete="off" class="form-style" id="sign-up-name" name="sign-up-name" placeholder="Повне ім'я" type="text">
                                                                <i class="input-icon uil uil-user">
                                                                </i>
                                                            </input>
                                                        </div>
                                                        <div class="form-group mt-2">
                                                            <input autocomplete="off" class="form-style" id="sign-up-login" name="sign-up-login" placeholder="Логін">
                                                                <i class="input-icon uil uil-at">
                                                                </i>
                                                            </input>
                                                        </div>
                                                        <div class="form-group mt-2">
                                                            <input autocomplete="off" class="form-style" id="sign-up-password" name="sign-up-password" placeholder="Пароль" type="password">
                                                                <i class="input-icon uil uil-lock-alt">
                                                                </i>
                                                            </input>
                                                        </div>
                                                        <input class="btn mt-4" id="sign-up-submit" name="sign-up-submit" type="submit" value="Зареєструватися">
                                                        </input>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </input>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<script src="https://cpwebassets.codepen.io/assets/common/stopExecutionOnTimeout-2c7831bb44f98c1391d6a4ffda0e1fd302503391ca806e7fcc7b9b87197aec26.js">
</script>
<script crossorigin="" src="https://cdpn.io/cpe/boomboom/pen.js?key=pen.js-12418115-cb79-680a-4d0c-fddbd1adbe10">
</script>
